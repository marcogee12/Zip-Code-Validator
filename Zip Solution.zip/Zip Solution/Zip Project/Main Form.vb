' Name:         Zip Project
' Purpose:      Validate a ZIP code.
' Programmer:   Marco Gomez on 6/30/2019

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtZip_Enter(sender As Object, e As EventArgs) Handles txtZip.Enter
        txtZip.SelectAll()
    End Sub

    Private Sub txtZip_TextChanged(sender As Object, e As EventArgs) Handles txtZip.TextChanged
        lblStatus.Text = String.Empty
    End Sub

    Private Sub txtZip_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtZip.KeyPress
        ' Allow only numbers and the Backspace key.

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub BtnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        'Creates scope for zipcode as the text in txtZip
        Dim zipCode As String = txtZip.Text

        'Give conditions that the entered zipcode must meet in order to be condsidered "valid".
        'If the zipcode doesnt meet those conditions it will output as invalid.
        If zipCode.Count <> 5 Then
            lblStatus.Text = "Invalid"
        ElseIf zipCode.Chars(0) <> "4" Then
            lblStatus.Text = "Invalid"
        ElseIf zipCode.Chars(1) <> "2" Then
            lblStatus.Text = "Invalid"
        ElseIf zipCode.Chars(2) <> "1" Then
            lblStatus.Text = "Invalid"
        ElseIf zipCode.Chars(3) <> "0" Then
            lblStatus.Text = "Invalid"
        ElseIf zipCode.Chars(4) <> "2" Xor zipCode(4) <> "3" Xor zipCode(4) <> "4" Then
            lblStatus.Text = "Invalid"
        Else
            lblStatus.Text = "Valid"
        End If
    End Sub

End Class
